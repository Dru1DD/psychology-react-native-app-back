module.exports = {
    secret: "SECRET_KEY_GENERATOR"
}